const homeDomain = "http://localhost:3002"  // React App Server url, port로 변경
const dataDomain = "http://ec2-3-38-45-235.ap-northeast-2.compute.amazonaws.com:8080"  // JSON-Server url port 로 변경 
//http://ec2-3-38-45-235.ap-northeast-2.compute.amazonaws.com:8080
//http://themostfavoriteidoru.s3-website.ap-northeast-2.amazonaws.com
export { homeDomain, dataDomain }